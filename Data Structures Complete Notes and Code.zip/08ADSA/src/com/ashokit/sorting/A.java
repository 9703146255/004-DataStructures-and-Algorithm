package com.ashokit.sorting;

public class A extends C{

	public void m1() {
		System.out.println("m1 method");
	}
}
