package com.ashokit.sorting;

public class C {

	public void m3() {
		System.out.println("m1 method");
	}
	
}
