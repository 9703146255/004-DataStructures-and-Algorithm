package com.ashokit.sorting;

public interface BankOfAmerica {

	public void minBal();
}
