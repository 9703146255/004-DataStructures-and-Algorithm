package com.ashokit.sorting;

public class UnitedStates implements BankOfAmerica{

	@Override
	public void minBal() {
		// TODO Auto-generated method stub
		System.out.println("min balance is 500 $");
		
	}

}
